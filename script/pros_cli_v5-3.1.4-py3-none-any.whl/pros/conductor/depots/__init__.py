from .depot import Depot
from .http_depot import HttpDepot
from .local_depot import LocalDepot
